# Deploy run-through

Taking shaneparreco.com from WordPress to GitHub Pages.

Read step 0 before anything else. The rest is about half an hour of work plus
a wait for DNS.

---

## 0. Images: already done

Every image on the site now lives in this repo. Nothing loads from
shaneparreco.com, so the cutover cannot break a photograph.

If you later find something missing while the old site is still up,
`bash tools/fetch-media.sh` will pull it. After DNS moves, that script stops
working, which is the only reason it is still here.

Have a quick look before you push:

```bash
python3 tools/build.py
python3 -m http.server 8000
# http://localhost:8000/al-bowers-and-an-epic-aviation-trip-nerd-alert/
# http://localhost:8000/costa-rica-video/
```

---

## 1. Back up WordPress properly

You have the posts and media XML already. Before DNS moves, also take:

- A full host backup or export (cPanel backup, or whatever your host offers).
- The `wp-content/uploads` folder over SFTP, as a belt-and-braces copy.

Keep the WordPress install running and paid up for at least a month after
cutover. It costs little and it is the only undo button you have.

---

## 2. Push to GitHub

```bash
cd shaneparreco-site
git init -b main
git add .
git commit -m "Static site: Terrain homepage, six sections, eight posts"
```

Create an empty repo on GitHub. **Public** is simplest; Pages on a private
repo needs a paid plan. There is nothing secret in here.

```bash
git remote add origin https://github.com/<you>/shaneparreco.com.git
git push -u origin main
```

Sanity check before pushing: `git status` should show no `.DS_Store`, and
`assets/img/` should be about 1.2 MB of real photographs.

---

## 3. Turn on Pages

Repo → **Settings** → **Pages**.

- Source: **Deploy from a branch**
- Branch: `main`, folder: **/ (root)**
- Save.

Wait for the first build. You will get a `https://<you>.github.io/...` URL.
Click it. Everything should work except the custom-domain bits.

`.nojekyll` is in the repo, so Pages serves the files as-is instead of
running them through Jekyll. Without it, anything in a folder starting with
an underscore would be dropped.

---

## 4. Add the domain in GitHub first, then DNS

GitHub's own docs are explicit about this order, and it matters: adding the
domain on GitHub before pointing DNS avoids a window where someone else
could claim it.

In **Settings → Pages → Custom domain**, enter `shaneparreco.com` and save.

The repo already contains a `CNAME` file with that value, so this should
match rather than create a second commit.

### Then at your DNS provider

Delete the existing A records pointing at your WordPress host. Add:

**Apex (`shaneparreco.com`), four A records:**

```
185.199.108.153
185.199.109.153
185.199.110.153
185.199.111.153
```

**Apex, four AAAA records (IPv6, optional but worth doing):**

```
2606:50c0:8000::153
2606:50c0:8001::153
2606:50c0:8002::153
2606:50c0:8003::153
```

**`www`, one CNAME:**

```
www  →  <you>.github.io
```

Note: `<you>.github.io`, with no repository name on the end. GitHub will
redirect www to the apex automatically, so the apex stays canonical, which
is what every URL in the sitemap and every canonical tag already assumes.

**Leave your MX records alone.** If email runs on this domain, touching MX
is how you lose it. Only the A, AAAA and the www CNAME change.

Check it from a terminal:

```bash
dig shaneparreco.com +noall +answer
dig www.shaneparreco.com +noall +answer
```

Propagation can take up to 24 hours, though it is usually much faster.

---

## 5. HTTPS

Once DNS resolves to GitHub, go back to **Settings → Pages** and tick
**Enforce HTTPS**. The certificate can take up to 24 hours to issue. If the
checkbox is greyed out, DNS has not fully propagated yet. Wait, do not
fiddle.

Do not skip this. Without it the site serves over plain HTTP and browsers
will say so.

---

## 6. Verify

Work down this list once the domain resolves.

**Pages load**

```
/                                     the landscape
/making/  /flying/  /building/
/music/   /racing/  /optimism/
/notebook/
```

**Old URLs still work.** These are the ones that would embarrass you if they
broke:

```
/music/                               kept
/optimism/                            kept
/home/                                bounces to /
/social-media-sucks/
/flying-training-and-travel/
/al-bowers-and-an-epic-aviation-trip-nerd-alert/
/wnc-paragliding-is-born/
/costa-rica-video/
/skygear-hub-has-launched/
/aktiga-the-future-of-vr/
/well-its-been-a-minute/              new
```

**The landscape.** Hover a light on desktop, tap one on a phone. Tab to one
and press Enter. Escape closes it.

**Analytics.** Open the site, then GA4 → Reports → Realtime. You should see
yourself within about thirty seconds. If not, check for an ad blocker before
you suspect the tag.

**Social preview.** Paste the URL into Slack or a draft post and confirm the
dark card with the ridgeline appears. If it does not, the OG image path is
wrong. `https://shaneparreco.com/assets/img/og-default.png` should load on
its own.

**404.** Visit `/does-not-exist/` and confirm you get the styled page.

**Search Console.** Add the property and submit
`https://shaneparreco.com/sitemap.xml`. Sixteen URLs. Worth doing the same
day so Google re-crawls the moved pages quickly.

---

## 7. If something is wrong

Point the apex A records back at your WordPress host. The old site comes
back as soon as DNS propagates. That is why step 1 says keep it running.

Nothing about this cutover is one-way except the media, which is why that is
step 0.

---

## Updating the site afterwards

```bash
# edit something in components/ or templates/
python3 tools/build.py
git add . && git commit -m "..." && git push
```

Pages rebuilds in a minute or so. There is no deploy pipeline to babysit.

Adding a post: copy any file in `templates/posts/`, change the `@var` lines
at the top, add a row to `templates/notebook.html` and to
`components/notebook-preview.html` if it should appear on the homepage, then
build and push.

`sitemap.xml` and `robots.txt` regenerate on every build from the pages that
actually exist, so they cannot drift.

---

## Worth doing in the first week

- **Self-host the fonts.** Two Google Fonts families are two extra
  connections and a flash of unstyled text on first load. Dropping the woff2
  files into `assets/fonts/` and swapping the `<link>` in
  `components/head.html` for `@font-face` rules removes every third-party
  request except analytics.
- **A carpentry photograph and a sim rig photograph.** Four of the six
  waypoint cards now use real images. The Shop and The Rig do not, because
  there was nothing suitable in the media library. Drop a 16:9 image into
  `assets/img/` as `wp-shop.jpg` or `wp-rig.jpg` and change one `src` and
  one `alt` in `components/terrain.html`.
- **Read `/optimism/` once more.** It mentions therapeutic support, carried
  over from the old site's framing.
